# Streamflow Node.js

Streaming banyak file ke banyak RTMP channel (YouTube, TikTok, Facebook, dll) langsung dari VPS menggunakan FFmpeg.

## Install

```bash
git clone https://github.com/darmaadi1993/streamflow-nodejs.git
cd streamflow-nodejs
npm install
```

Pastikan **FFmpeg** sudah terpasang di VPS:
```bash
sudo apt update && sudo apt install ffmpeg -y
```

## Konfigurasi
Edit `config.json`:
```json
{
  "streams": [
    {
      "file": "/path/to/video1.mp4",
      "urls": [
        "rtmp://a.rtmp.youtube.com/live2/YOUR_YOUTUBE_KEY",
        "rtmp://live.tiktok.com/YOUR_TIKTOK_KEY"
      ]
    }
  ]
}
```

## Jalankan
```bash
npm start
```
