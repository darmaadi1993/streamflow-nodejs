const { spawn } = require('child_process');
const cron = require('node-cron');
const config = require('./config.json');

function startStream(file, url) {
  console.log(`Starting stream: ${file} -> ${url}`);
  const ffmpeg = spawn('ffmpeg', [
    '-re',
    '-i', file,
    '-c:v', 'libx264',
    '-preset', 'veryfast',
    '-b:v', '2500k',
    '-maxrate', '2500k',
    '-bufsize', '5000k',
    '-c:a', 'aac',
    '-ar', '44100',
    '-b:a', '128k',
    '-f', 'flv', url
  ]);

  ffmpeg.stdout.on('data', data => console.log(`stdout: ${data}`));
  ffmpeg.stderr.on('data', data => console.error(`stderr: ${data}`));
  ffmpeg.on('close', code => console.log(`Stream ended with code ${code}`));
}

// Start all streams immediately
config.streams.forEach(stream => {
  stream.urls.forEach(url => {
    startStream(stream.file, url);
  });
});
